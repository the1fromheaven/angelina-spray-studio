# Angelina Spray — Portfolio starter

A responsive editorial-style portfolio starter for graphic design, brand identity and web design.

## Files
- `index.html` — page structure and editable portfolio content
- `styles.css` — visual design, layout and responsive styles
- `script.js` — mobile navigation
- `assets/rome-italy.png` — your Rome poster, if included

## Before publishing
1. Replace the example project images and concept descriptions with your own work or properly licensed imagery.
2. Replace `YOUR-GUARDIAN-APPROVED-EMAIL@example.com` with a contact address approved and managed with a parent/guardian. Alternatively, remove the email link and use a supervised contact method.
3. Review every public detail. Do not publish your school, home address, phone number, daily schedule or other private information.
4. Clearly label fictional/self-initiated work as a concept. Do not imply that concept work was commissioned.
5. Optimize large images to keep the site quick to load.

## Publish
### GitHub + Cloudflare Pages
1. Create a GitHub repository and upload the contents of this folder.
2. In Cloudflare Pages, create a project connected to that repository.
3. Use the repository root as the build directory. No build command is needed for this plain HTML/CSS/JS site.
4. Deploy. Cloudflare will provide a public preview URL.

You can also use GitHub Pages for a personal static portfolio. Review each provider's current terms and usage limits before publishing.
